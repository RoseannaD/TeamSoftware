#Needs to use python 3.8, Needs yfinance libary pip installed to run
import yfinance as yahooFinance
import pandas as pd
import sys

fTest = open('length.txt', 'w')
fTest.write('0')
fTest.close()

#stockName=sys.argv[1]
#startDate=sys.argv[2]
#endDate=sys.argv[3]
stockName='Subway'
startDate='2003-01-13'
endDate='2019-06-01'
safe =0



data = startDate.split("-")





num1 = int(data[1])
num2 = int(data[2])
num0 = int(data[0])

if (num1 < 1 or num1 > 12):
    safe = safe + 1
    
if (num1 == 1 or num1 == 3 or num1 ==5 or num1 == 7 or num1 == 8 or num1 == 10 or num1 == 12):
    if (num2 < 1 or num2 > 31):
        safe = safe + 1
        
if (num1 ==4 or num1 == 6 or num1==9 or num1 ==11):
    if (num2 < 1 or num2 > 30):
        safe = safe + 1
if (num1==2):
    if (num2 < 1 or num2 > 28):
        safe = safe + 1
        
if (num0 >2020 or num0< 1997):
    safe = safe + 1
    
data = endDate.split("-")

num1 = int(data[1])
num2 = int(data[2])
num0 = int(data[0])

if (num1 < 1 or num1 > 12):
    safe = safe + 1
    
if (num1 == 1 or num1 == 3 or num1 ==5 or num1 == 7 or num1 == 8 or num1 == 10 or num1 == 12):
    if (num2 < 1 or num2 > 31):
        safe = safe + 1
        
if (num1 ==4 or num1 == 6 or num1==9 or num1 ==11):
    if (num2 < 1 or num2 > 30):
        safe = safe + 1
if (num1==2):
    if (num2 < 1 or num2 > 28):
        safe = safe + 1
        
if (num0 >2020 or num0< 1997):
    safe = safe + 1
    


intLength = 0
Length = ''
stringData = ''
if (safe == 0):
    try:
        yahooData = yahooFinance.download(stockName, startDate, endDate)
        intLength = len(yahooData.index)
        Length = str(intLength)

        stringData = yahooData.to_string(buf=None, columns=None, col_space=None, header=True, index=True, na_rep='NaN', formatters=None, float_format=None, sparsify=None, index_names=True, justify=None, max_rows=None, min_rows=None, max_cols=None, show_dimensions=False, decimal='.', line_width=None)

        fData = open('output.txt', 'w')
        fData.write(stringData)
        fData.close()

        fLength = open('length.txt','w')
        fLength.write(Length)
        fData.close()
        print('Completed')
    except:
        print("Company or date not valid")
else:
    print("Date not valid")
#BL
