fData = open('length.txt', 'w')
fData.write('0')
fData.close()
